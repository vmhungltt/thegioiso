<!DOCTYPE html>
<html>
<head>
    <title>Xác thực đơn hàng</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>

   <h3> Mã OTP : <b>{{$details['otp']}}</b></h3>
</body>
</html>
