<ul>
    <li class="cartSubT">Tạm tính:
        <span>{{ number_format($total, 0, '', '.') }}đ</span></li>
    <li class="cartSubT">Tổng cộng:
        <span>{{ number_format($total, 0, '', '.') }}đ</span></li>
</ul>
<a class="proceedbtn" href="#">Tiến hành đặt hàng</a>
<div class="multiCheckout">
    <a href="#">Checkout with Multiple Addresses</a>
</div>
